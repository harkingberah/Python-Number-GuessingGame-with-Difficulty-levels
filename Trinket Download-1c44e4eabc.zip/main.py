import random
user_choice=input("choose a difficulty level between 1 and 3:\n 1 for Easy,\n 2 for Medium, and\n 3 for Hard: ").strip()
randnum=0
while user_choice.isdigit()== False or int(user_choice)>4:
     user_choice=input("choose a difficulty level between 1 and 3: 1 for Easy, 2 for Medium, and 3 for Hard: ").strip()
if int(user_choice)==1:
    randnum=random.randint(1,100)
elif int(user_choice)==2:
    randnum=random.randint(1,500)
else:
    randnum=random.randint(1,1000)
print(randnum)
tries=1
while tries<=10:
    guess=input("guess the random number: ")
    if guess.isnumeric()==False:
        break
    if guess.isdigit()==False:
        print("invalid input")
        continue
    if int(guess)==randnum:
        print("you are correct")
        print(f"it took you {tries} attempt(s) to guess the correct random number")    
        break
    elif int(guess)>randnum:
        print("you guess is bigger than the random number")
    elif int(guess)<randnum:
        print("you guess is smaller than the random number")
    if tries==10:
        print(f"you could not guess the random number in 10 attempts.\nThe random number is {randnum}")    
    tries=tries + 1
  

